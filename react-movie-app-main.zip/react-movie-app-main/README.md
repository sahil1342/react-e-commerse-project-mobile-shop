### Getting Started with clone the above repository using `git clone {repository url}` ..
This project was bootstrapped with [Create React-vite App](https://vitejs.dev/guide/).

### In the project directory, you can run `npm install` to install node_modules.
### Then run `npm run dev` to run project on browser.
Runs the app in the development mode.\
Open [http://localhost:5173/](http://localhost:5173) to view it in your browser..

## Banner
![image0](https://github.com/mvaibhav131/react-movie-app/assets/98808183/26e544ab-4ecc-40b5-b32e-fa640e0866f1)

## Upcoming and Trending Movie,Tv show's
![image1](https://github.com/mvaibhav131/react-movie-app/assets/98808183/741e40e3-0c5c-41a1-bf2b-85219b5ec4df)

## Popular and Top rated Movie,Tv show's
![image2](https://github.com/mvaibhav131/react-movie-app/assets/98808183/b58d1462-6434-4c09-83cf-95b9e668a6f5)

## Tv Show's
![image3](https://github.com/mvaibhav131/react-movie-app/assets/98808183/ee1bc5c8-8bb3-48fe-855b-7dd95cb34b8c)

## Login & Register
![image4](https://github.com/mvaibhav131/react-movie-app/assets/98808183/cb2a7322-15e3-4347-a75e-9072c8f64614)

## Footer
![image5](https://github.com/mvaibhav131/react-movie-app/assets/98808183/45eed4cd-baeb-477f-856c-2be620589fa3)
